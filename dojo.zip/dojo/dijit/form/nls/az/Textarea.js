//>>built
define("dijit/form/nls/az/Textarea",{iframeEditTitle:"Redakt\u0259 sah\u0259si",iframeFocusTitle:"Redakt\u0259 sah\u0259si \u00e7\u0259r\u00e7iv\u0259si"});
//# sourceMappingURL=Textarea.js.map