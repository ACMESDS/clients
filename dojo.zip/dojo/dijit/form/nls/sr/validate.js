//>>built
define("dijit/form/nls/sr/validate",{invalidMessage:"Uneta vrednost nije va\u017ee\u0107a.",missingMessage:"Ova vrednost je potrebna.",rangeMessage:"Ova vrednost je van opsega."});
//# sourceMappingURL=validate.js.map