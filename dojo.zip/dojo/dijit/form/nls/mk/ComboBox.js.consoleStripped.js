define("dijit/form/nls/mk/ComboBox", {      
//begin v1.x content
		previousMessage: "Претходни избори",
		nextMessage: "Повеќе избори"
//end v1.x content
});

