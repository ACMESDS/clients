//>>built
define("dijit/form/nls/kk/ComboBox",{previousMessage:"\u0410\u043b\u0434\u044b\u04a3\u0493\u044b \u043d\u04b1\u0441\u049b\u0430\u043b\u0430\u0440",nextMessage:"\u0411\u0430\u0441\u049b\u0430 \u043d\u04b1\u0441\u049b\u0430\u043b\u0430\u0440"});
//# sourceMappingURL=ComboBox.js.map