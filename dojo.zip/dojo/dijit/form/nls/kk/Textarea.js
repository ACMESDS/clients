//>>built
define("dijit/form/nls/kk/Textarea",{iframeEditTitle:"\u04e9\u04a3\u0434\u0435\u0443 \u0430\u0443\u043c\u0430\u0493\u044b",iframeFocusTitle:"\u04e9\u04a3\u0434\u0435\u0443 \u0430\u0443\u043c\u0430\u0493\u044b\u043d\u044b\u04a3 \u0436\u0430\u049b\u0442\u0430\u0443\u044b"});
//# sourceMappingURL=Textarea.js.map