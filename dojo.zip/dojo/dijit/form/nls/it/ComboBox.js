//>>built
define("dijit/form/nls/it/ComboBox",{previousMessage:"Scelte precedenti",nextMessage:"Scelte successive"});
//# sourceMappingURL=ComboBox.js.map