//>>built
define("dijit/form/nls/it/validate",{invalidMessage:"Il valore immesso non \u00e8 valido.",missingMessage:"Questo valore \u00e8 obbligatorio.",rangeMessage:"Questo valore \u00e8 fuori dall'intervallo consentito."});
//# sourceMappingURL=validate.js.map