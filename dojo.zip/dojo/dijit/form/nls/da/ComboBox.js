//>>built
define("dijit/form/nls/da/ComboBox",{previousMessage:"Forrige valg",nextMessage:"Flere valg"});
//# sourceMappingURL=ComboBox.js.map