//>>built
define("dijit/form/nls/de/ComboBox",{previousMessage:"Vorherige Auswahl",nextMessage:"Weitere Auswahlm\u00f6glichkeiten"});
//# sourceMappingURL=ComboBox.js.map