//>>built
define("dijit/form/nls/bs/ComboBox",{previousMessage:"Prethodni izbori",nextMessage:"Jo\u0161 izbora"});
//# sourceMappingURL=ComboBox.js.map