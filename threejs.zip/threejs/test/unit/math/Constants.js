/**
 * @author bhouston / http://exocortex.com
 */

var x = 2;
var y = 3;
var z = 4;
var w = 5;

var negInf2 = new THREE.Vector2( -Infinity, -Infinity );
var posInf2 = new THREE.Vector2( Infinity, Infinity );

var zero2 = new THREE.Vector2();
var one2 = new THREE.Vector2( 1, 1 );
var two2 = new THREE.Vector2( 2, 2 );

var negInf3 = new THREE.Vector3( -Infinity, -Infinity, -Infinity );
var posInf3 = new THREE.Vector3( Infinity, Infinity, Infinity );

var zero3 = new THREE.Vector3();
var one3 = new THREE.Vector3( 1, 1, 1 );
var two3 = new THREE.Vector3( 2, 2, 2 );
