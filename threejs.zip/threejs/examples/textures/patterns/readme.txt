Texture "bright_squares256.png" from http://subtlepatterns.com/

Slightly modified to have more GPU friendly sizes.

Licensed under a Creative Commons Attribution 3.0 Unported License:
http://creativecommons.org/licenses/by/3.0/