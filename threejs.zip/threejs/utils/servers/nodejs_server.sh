#!/bin/sh

cd `dirname $0`/../../
node utils/servers/simplehttpserver.js