#!/bin/sh

python sublime.py --include common --include extras --output sublimetext2/threejs.sublime-completions
