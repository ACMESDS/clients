module.exports = require('es6-promise').Promise;
